
<?php include('registration.php')  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<div class="header">

<h2>Welcome Page</h2>

</div>

<div class="content">

   

    
     <p>Welcome <strong><?php echo $_SESSION['fname']; ?></strong></p>
     <p><a href="" style="color:red;" >Logout</a></p>
    
  


</div>


</body>
</html>