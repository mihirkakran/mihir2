<?php

$email1 = $_POST['email1'];
$pass1 = $_POST['pass1'];

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "rishabh";


$conn = new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error)
{
   die('Connection Failed : '.$conn->connect_error);
}
else
{
  
   $statement = $conn->prepare("select * from registration where email=? and password=?");
   $sql = $statement->bind_param("ss",$email1, $pass1);
   
   $sttmnt = "select * from registration where email='".$email1."' and password='".$pass1."'";
   $result = mysqli->query($conn, $sttmnt);

   

   if($result->num_rows > 0)
   {
       echo"Login Successful";
       echo "<a href='http://localhost/phpproject/loginpage.html'>Login</a> &nbsp;&nbsp; <a href='http://localhost/phpproject/index.html'>SignUp</a>";
   }
   else
   {
       echo "<h>Incorrect username / password</h></br></br>";
       echo "<a href='http://localhost/phpproject/loginpage.html'>Login</a> &nbsp;&nbsp; <a href='http://localhost/phpproject/index.html'>SignUp</a>";
   }
  
$statement->close();
$conn-> close();

}
?>
