<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$pass = $_POST['password'];

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "rishabh";


$conn = new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error)
{
   die('Connection Failed : '.$conn->connect_error);
}
else
{
   $statement = $conn->prepare("insert into registration(first_name, last_name, email, password)
       values(?, ?, ?, ?)");

   $statement->bind_param("ssss",$fname, $lname, $email, $pass);
   $statement->execute();

   echo "Welcome ". $fname;

  $statement->close();
  $conn->close();
  $_SESSION['fname'] = $fname;

header('location: welcome.html');


}


?>
